/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.*;

/**
 *
 * @author Diego (Drako Lieter)
 */
public class VtnInicioC implements ActionListener{
    private VentanaInicio v;

    public VtnInicioC(VentanaInicio vI) {
        this.v=vI;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(v.getBtnRegistrar()==e.getSource()){
            VentanaRegistrarVenta vRegistrar=new VentanaRegistrarVenta();
            vRegistrar.setVisible(true);
            v.setVisible(false);
        }else if(v.getBtnVer()==e.getSource()){
            VentanaVerRegistro vVer=new VentanaVerRegistro();
            vVer.setVisible(true);
            v.setVisible(false);
        }
    }
    
    
}

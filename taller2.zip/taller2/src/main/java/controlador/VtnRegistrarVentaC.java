/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import dao.VentaDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Vendedor;
import modelo.Venta;
import vista.VentanaInicio;
import vista.VentanaRegistrarVenta;

/**
 *
 * @author Diego (Drako Lieter)
 */
public class VtnRegistrarVentaC implements ActionListener{
    private VentanaRegistrarVenta v;
    private VentaDAO vDAO;
    private VentanaInicio vI;
    
    public VtnRegistrarVentaC(VentanaRegistrarVenta v,VentanaInicio vI) {
        this.v = v;
        this.vI=vI;
        this.vDAO=new VentaDAO();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(v.getBtnRegistrar()==e.getSource()){
            Vendedor ven=(Vendedor) v.getVenderorComboBox().getSelectedItem();
            String sucursal=(String) v.getSucursalCB().getSelectedItem();
            String fecha=v.getFechaTF().getText();
            int monto=Integer.parseInt(v.getMontoTF().getText());
            Venta venta=new Venta(sucursal,monto,fecha,ven);
            this.vDAO.insertVenta(venta);
            this.vI.setVisible(true);
            this.v.dispose();
        }
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import dao.VentaDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.VentanaInicio;
import vista.VentanaVerRegistro;

/**
 *
 * @author Diego (Drako Lieter)
 */
public class VtnVerRegistroC implements ActionListener{
    private VentanaVerRegistro v;
    private VentaDAO vDAO;
    private VentanaInicio vI;

    public VtnVerRegistroC(VentanaVerRegistro v, VentanaInicio vI) {
        this.v = v;
        this.vDAO=new VentaDAO();
        this.vI = vI;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}

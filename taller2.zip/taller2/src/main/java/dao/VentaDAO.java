/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import modelo.Vendedor;
import modelo.Venta;

/**
 *
 * @author Diego (Drako Lieter)
 */
public class VentaDAO {
    private Conexion con;

    public VentaDAO() {
        con=new Conexion();
    }
    
    public ArrayList<Venta> getVentas(){
        ArrayList<Venta>ventas=new ArrayList<>();
        String sql="SELECT * FROM venta";
        VendedorDAO vDAO=new VendedorDAO();
        
        try{
            Connection accesoBD = con.getConexion();
            Statement st = accesoBD.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                int id=rs.getInt("id_venta");
                String sucursal=rs.getString("sucursal");
                int monto=rs.getInt("monto");
                String fecha=rs.getString("fecha");
                int id_vendedor=rs.getInt("id_vendedor");
                Vendedor v= vDAO.getById(id_vendedor);
                ventas.add(new Venta(id,sucursal,monto,fecha,v));
            }
            return ventas;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
    public ArrayList<Venta> getVentasXMes(String fecha){
        ArrayList<Venta>ventas=new ArrayList<>();
        String sql="SELECT * FROM venta WHERE fecha BETWEEN '2019-xx-01' AND '2019-xx-31'";
        try{
            Connection accesoBD = con.getConexion();
            Statement st = accesoBD.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                ventas.add(null); // llegue hasta aca... :(
            }
            return ventas;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
    public void insertVenta(Venta v){
        Connection accesoBD=con.getConexion();
        try{
            String sql="INSERT INTO Venta(sucursal,monto,fecha,id_vendedor) VALUES('"+v.getSucursal()+"',"+v.getMonto()+",'"+v.getFecha()+"','"+v.getVendedor().getId_vendedor()+"')";
            Statement st=accesoBD.createStatement();
            st.executeUpdate(sql);
        }catch(Exception e){
            System.out.println("");
            System.out.println("Error al insertar");
            e.printStackTrace();
        }
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.Vendedor;

/**
 *
 * @author Diego (Drako Lieter)
 */
public class VendedorDAO {
    private Conexion con;

    public VendedorDAO() {
        con = new Conexion();
    }
    
    public Vendedor getById(int idVendedor){
        Vendedor v = null;
        String sql="SELECT * FROM vendedor WHERE id="+idVendedor;
        try{
            Connection accesoBD = con.getConexion();
            Statement st = accesoBD.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                int id=rs.getInt("id_vendedor");
                String nombre=rs.getString("nombre");
                String apellido=rs.getString("apellido");
                String rut=rs.getString("rut");
                v=new Vendedor(id,nombre,apellido,rut);
            }
            return v;
        }catch(Exception e){
           e.printStackTrace();
           return null;
        }
    }
    
    public ArrayList<Vendedor> getAllVendedor(){
        ArrayList<Vendedor> vendedores=new ArrayList<>();
        String sql="SELECT * FROM vendedor";
        try{
            Connection accesoBD = con.getConexion();
            Statement st = accesoBD.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                int id=rs.getInt("id_vendedor");
                String nombre=rs.getString("nombre");
                String apellido=rs.getString("apellido");
                String rut=rs.getString("rut");
                Vendedor v=new Vendedor(id,nombre,apellido,rut);
                vendedores.add(v);
            }
            return vendedores;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
}
